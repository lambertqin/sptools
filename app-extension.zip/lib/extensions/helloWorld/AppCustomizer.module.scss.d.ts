declare const styles: {
    app: string;
    top: string;
    bottom: string;
};
export default styles;
//# sourceMappingURL=AppCustomizer.module.scss.d.ts.map