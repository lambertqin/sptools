/* tslint:disable */
require("./AppCustomizer.module.css");
const styles = {
  app: 'app_64162608',
  top: 'top_64162608',
  bottom: 'bottom_64162608'
};

export default styles;
/* tslint:enable */