Overview
========
The 'Robust Office Inventory' script allows to create a list of all installed applications of the Office families 2000, XP, 2003, 2007, 2010, 2013 and O365.
Scope of the inventory is for use with Microsoft customer support purposes.

Usage
=====
Double click or run 'ROIScan.vbs'
The log will be opened automatically when the script execution completes.

In case of a failure please contact your support professional to obtain the "Debug" version of the script "ROIScan_Debug.vbs"
The inventory log will be created as "%Computername%_ROIScan.log" in the %TEMP% folder 
An additional debug log is created along with the inventory log as "%Computername%_ROIScan_Debug.log"

Advanced Usage Options
======================
 ROIScan.vbs [Options]

 /?                     Display this help
 /All                   Includes non Office products
 /Basic			Log less product details
 /Full                  Log all additional product details
 /Verbose               Log additional product details
 /Logfolder <Path>      Custom directory for log file
 /Quiet                 Don't prompt for elevation and don't open log when done

Log Contents
============
General Properties
 - Inventory log create date & time
 - Computername
 - Windows Installer Version
 - User Name, SID
 - OS Name, SP level, Version, Codepage, Country Code, Language, 64bit (yes/no)
 - Build number of the inventory script
 - Logfile path & name
 - Script settings
 - Scan duration

Each Office application will be logged with
 - ProductVersion
 - ServicePack Level
 - ProductCode
 - InstallDate
 - Msi ProductName
 - UserSid (for installed product)
 - ProductContext
 - ProductState
 - Original .msi Name
 - Cached .msi Package
 - Transforms
 - Build/Origin
 - Package Code
 - Notes
 - Errors
 - Config ProductName
 - Config PackageID
 - Chained Packages
 - Patches
 - InstallSource
 - FeatureStates (optional)
Note: Logged details may vary depending on the product version.

Issues that are detected by the script will be automatically listed as 'Review Items' in the log.


Prerequisites
=============
The script requires a minimum Windows Installer version of 2.x.
In addition a failure on 'CreateObject' of one of these classes will terminate the script
 - "WScript.Shell"
 - "WindowsInstaller.Installer"
 - "Scripting.FileSystemObject"
 - "winmgmts:\\.\root\default:StdRegProv" (WMI Registry Provider)

Note: As default the first priority is to use the Windows Installer object model for all operations.
A fallback to direct registry or file access can happen if the Windows Installer Object returns an error or has no method to provide the required operation.


FAQ
===
* Which versions of Office does this script detect?

All versions of Office starting with Office 2000.



* Does the script cover Office server products?

Yes it  does.



* Is the script 64bit aware?

Yes it is.



* The SP level is reported as "?" instead of the SP level.

The script has a hardcoded list to translate a ProductVerion into the SP level.

If this is a ProductVersion that's released for several month please report this



* Why does the script prompt for elevation / needs to be run as administrator?

Some of the used Windows Installer API's require elevated permissions to detect applications outside of the current user scope. 
If the elevation fails the script will run in the user context and report the permission issue.



