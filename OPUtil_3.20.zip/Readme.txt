Usage
=====

 cscript OPUtil.vbs [/Option] ...



Options
=======

 /RepairCache   Tries to restore missing items in the local WI cache
   /SRestoreLocation=   A list of fully qualified paths to folders with .msp files, separated by semicolons
                        <Folder01>;<\\Server02\Share02>;...

 /ReconcileCache Unregisters missing patches in the cache to unblock broken WI configurations

 /ApplyPatch    Apply patches from current folder and SUpdateLocation
   /SUpdateLocation=    A list of fully qualified paths to folders with .msi and/or .msp files, separated by semicolons
                        <Folder01>;<\\Server02\Share02>;...
   /ExcludeCache        Will not apply any patches from %windir%\installer folder
   /IncludeOctCache     Includes OCT patches from %windir%\installer folder into patch detection

 /RemovePatch=  Uninstall specified list of patches, separated by semicolons
                Accepts KBxxxxxx;{PatchCode};<FullPath>;SUPERSEDED

 /CleanCache    Removes unreferenced (orphaned) patch files from the local WI cache

 /CabExtract=<Patch>    Extracts the patch embedded .CAB file to the %temp% folder

 /ViewPatch=<Patch>     Displays content details of the patch in an Excel Worksheet

 /DetectOnly    Create a log file but do not execute any actions

 /q             Suppresses the automatic display of the log file


 /register      Registers OPUtil context menu extensions for .msp files


 /unregister    UnRegisters OPUtil context menu extensions for .msp files


Note: If no options are provided then 'RepairCache' and 'ApplyPatch' modes are enabled.



Examples
========

* Default 'RepairCache' & 'ApplyPatch' from current directory:
   cscript.exe OPUtil.vbs

* Repair a broken Windows Installer Cache:
   cscript.exe OPUtil.vbs /RepairCache /SRestoreLocation=<\\Location1\ShareName>;<\\Location2\ShareName>

* Create a log for applicability of specific patches:
   cscript.exe OPUtil.vbs /ApplyPatch /SUpdateLocation=<\\Location1\ShareName>;<\\Location2\ShareName> /ExcludeCache /DetectOnly

* Install applicable patches (including local Windows Installer cache):
   cscript.exe OPUtil.vbs /ApplyPatch /SUpdateLocation=<\\Location1\ShareName>;<\\Location2\ShareName>

* UnInstall patch(es):
   cscript.exe OPUtil.vbs /RemovePatch=KB123456;KB654321
   cscript.exe OPUtil.vbs /RemovePatch={PatchCode}
   cscript.exe OPUtil.vbs /RemovePatch=Superseded


NOTE:	For all usage scenarios it's possible to append the "/DetectOnly" switch which will *only log* the actions.
	No changes will applied to the computer!



IMPORTANT HINT
==============
To figure out why a given patch cannot be applied follow these steps:
 1. Place the .msp files and the script in the same folder
 2. Run the script from an ELEVATED COMMAND WINDOW
 3. Collect the 'OPUtil.log' that's automatically opened and all generated verbose logs from the %temp% folder.
    Verbose logs are generated as "<ProductCode>_MspApply.log" / "<ProductCode>_<PatchCode>_MspRemove.log"


Note: 
-----
In 'ApplyPatch' mode the script will automatically check if the current directory contains .msp files and apply them to applicable targets.
If no .msp files are found in the script folder it will check the folder for "Microsoft Self Extractor" .exe packages
and attempt to extract the patches. Only Office 2007 and higher "Microsoft Self Extractor" packages are supported.

As alternative to place the .msp files in the current folder - use the "SUpdateLocation=" property to specify folders
that contain .msp files.

Important: 
----------
Instead of relying on the script to extract the .msp files the recommended way is to do that before the script is called.

Office 2000 - 2003 .exe patch downloads (IExpress packages) can be extracted with	"<PatchFileName>.exe /C"
Office 2007 and later .exe patch downloads can be extracted with			"<PatchFileName>.exe /extract"


More Info
=========
Works with CScript and WScript.
Recommended usage is with CScript to allow progress updates on the command window.
